/*
Activité 1
*/

// Liste des liens Web à afficher. Un lien est défini par :
// - son titre
// - son URL
// - son auteur (la personne qui l'a publié)
var listeLiens = [
    {
        titre: "So Foot",
        url: "http://sofoot.com",
        auteur: "yann.usaille"
    },
    {
        titre: "Guide d'autodéfense numérique",
        url: "http://guide.boum.org",
        auteur: "paulochon"
    },
    {
        titre: "L'encyclopédie en ligne Wikipedia",
        url: "http://Wikipedia.org",
        auteur: "annie.zette"
    }
];
// Explications :
// Pour faire le devoir, j'ai considéré chaque lien comme étant un bloc
// Dans chaque bloc, il y a 2 lignes d'informations, que j'ai créé séparément
// J'ai ensuite introduit ces 2 lignes dans la <div> bloc, puis chaque bloc à été introduit dans la <div> initiale


// Pour chaque lien, on crée un bloc d'informations grâce à la boucle suivante :
listeLiens.forEach(function (lien) {

    // Création d'une <div> pour chaque lien
    var divElt = document.createElement("div");
    divElt.setAttribute("class", "lien");//on définit une classe "lien" à la div créée précedemment

    // Création du lien principal bleu
    var titreElt = document.createElement("h3");
    var aElt = document.createElement("a");
    aElt.href = lien.url;//on définit la valeur de l'attribut href du lien <a>
    aElt.textContent = lien.titre;//on définit le texte que le lien <a> affichera
    aElt.style.color = "#428bca";
    aElt.style.textDecoration = "none";
    titreElt.appendChild(aElt);//le lien <a> devient enfant du titre <h3>
    titreElt.style.display = "inline";

    // Création de l'url
    var urlElt = document.createElement("p");
    var premierSpanElt = document.createElement("span");
    urlElt.appendChild(premierSpanElt);//le <span> devient enfant du <p>
    premierSpanElt.textContent = lien.url;//on définit le contenu du <span>
    urlElt.style.display = "inline";
    urlElt.style.marginLeft = "10px";

    // Création de la première ligne de description ET ajout du titre et de l'url
    var premiereLigneElt = document.createElement("p");
    premiereLigneElt.appendChild(titreElt);//on ajoute le titre
    premiereLigneElt.appendChild(urlElt);//on ajoute l'url qui sera dernier enfant
    premiereLigneElt.style.margin = "0";

    // Création de la deuxième ligne de description et ajout de l'auteur
    var deuxiemeLigneElt = document.createElement("p");
    var deuxiemeSpanElt = document.createElement("span");
    deuxiemeLigneElt.appendChild(deuxiemeSpanElt);//le <span> devient enfant du <p> créé avant
    deuxiemeSpanElt.textContent = "Ajouté par " + lien.auteur;//on définit le contenu du <span>
    deuxiemeLigneElt.style.margin = "0";

    // Ajout de la première ligne à la <div> du lien
    divElt.appendChild(premiereLigneElt);
    // Ajout de la deuxième ligne à la <div> du lien
    divElt.appendChild(deuxiemeLigneElt);

    // Ajout de la <div> à la <div> initiale ayant pour identifiant "contenu"
    document.getElementById("contenu").appendChild(divElt);
});
